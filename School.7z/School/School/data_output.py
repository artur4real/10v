import mysql.connector

# Подключение к базе данных
connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="school"
)

def get_all_students():
    with connection.cursor() as cursor:
        select_all_query = "SELECT * FROM Student"
        cursor.execute(select_all_query)
        students = cursor.fetchall()
        return students


# Пример использования функции

students = get_all_students()
if students:
    print("Данные студентов:")

    for student in students:
        student_data = ', '.join(str(value) for value in student)
        print(student_data)
else:
    print("Таблица Student пуста или произошла ошибка соединения с базой данных.")

# Закрытие соединения с базой данных
connection.close()