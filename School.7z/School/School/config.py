host = "localhost"
user = "root"
password = ""
bd_name = "school"
